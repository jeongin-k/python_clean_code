from enum import Enum

class X10HouseCode(Enum):
    X10_A = 1
    X10_B = 2
    X10_C = 3
    X10_D = 4
    X10_E = 5
    X10_F = 6
    X10_G = 7
    X10_H = 8
    X10_I = 9
    X10_J = 10
    X10_K = 11
    X10_L = 12
    X10_M = 13
    X10_N = 14
    X10_O = 15
    X10_P = 16

